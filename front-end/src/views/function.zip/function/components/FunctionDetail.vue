<template>
  <el-drawer size="40%" @open="onOpen" @close="onClose">
    <!-- function info -->
    <el-form v-loading="loadingDetail" :rules="rules" style="padding: 0 20px" :model="info">
      <el-descriptions title="function info" border size="small">
        <template #extra>
          <el-button v-if="!editable" type="primary" size="small" @click="onChgEditable"> Edit </el-button>
          <span v-else>
            <el-button type="primary" :style="{ marginRight: '16px' }" @click="saveEdit"> Save </el-button>
            <el-button @click="cancelEdit"> Cancel </el-button>
          </span>
        </template>
        <el-descriptions-item label="Name" class="inputDefault">
          <el-input v-model="info.name" readonly />
        </el-descriptions-item>
        <el-descriptions-item label="Runtime" :span="2">
          {{ info.runtime }}
        </el-descriptions-item>
        <el-descriptions-item class="inputDefault" label="Classname" :span="3">
          <el-form-item prop="className" :wrapper-col="{ span: 24 }" :style="{ width: '100%' }">
            <el-input
              v-model="info.className"
              class="inputDefault"
              :readonly="!editable"
              :class="{ editable: !editable }"
            />
          </el-form-item>
        </el-descriptions-item>
        <el-descriptions-item label="input" :span="3">
          <el-form-item prop="input">
            <el-input
              v-model="info.input"
              class="inputDefault"
              :readonly="!editable"
              :class="{ editable: !editable }"
            />
          </el-form-item>
        </el-descriptions-item>
        <el-descriptions-item class="inputDefault" label="Output" :span="3">
          <el-form-item prop="output">
            <el-input
              v-model="info.output"
              class="inputDefault"
              :readonly="!editable"
              :class="{ editable: !editable }"
            />
          </el-form-item>
        </el-descriptions-item>
        <el-descriptions-item v-if="editable" class="uploadBox" label="File" :span="3">
          <el-upload
            drag
            name="data"
            style="
               {
                width: 100%;
              }
            "
          >
            <i class="el-icon-upload"></i>
            <p class="el-upload-text">Click or drag file to this area to upload</p>
            <p class="el-upload-hint">Only jar files are supported</p>
          </el-upload>
        </el-descriptions-item>
      </el-descriptions>
      <el-descriptions title="Stats" border size="small" :column="2" :style="{ margin: '24px 0' }">
        <el-descriptions-item label="Received">
          {{ info.receivedTotal || 0 }}
        </el-descriptions-item>
        <el-descriptions-item label="Processed Successfully">
          {{ info.processedSuccessfullyTotal || 0 }}
        </el-descriptions-item>
        <el-descriptions-item label="System Exceptions">
          {{ info.systemExceptionsTotal || 0 }}
        </el-descriptions-item>
        <el-descriptions-item label="Avg Process Latency">
          {{ info.avgProcessLatency || 0 }}
        </el-descriptions-item>
      </el-descriptions>
      <el-descriptions title="Status" border size="small" :column="2" :style="{ margin: '24px 0' }">
        <el-descriptions-item label="Number of instances"> 0 </el-descriptions-item>
        <el-descriptions-item label="Number of running"> 0 </el-descriptions-item>
      </el-descriptions>
    </el-form>
  </el-drawer>
</template>

<script>
  export default {
    name: 'FunctionDetailVue',
    data() {
      return {
        editable: false,
        rules: {
          funcName: [{ require: true, message: 'Please input your Function name!', trigger: 'change' }],
          className: [{ required: true, message: 'Please input your className!', trigger: 'change' }],
          input: [{ required: true, message: 'Please input your Input!', trigger: 'change' }],
          output: [{ required: true, message: 'Please input your Output!', trigger: 'change' }]
        },
        inputs: [],
        file: '',
        info: {},
        beforeEditInfo: {}
      }
    },
    prop: {
      visible: {
        type: Boolean,
        default: false
      },
      loadingDetail: {
        type: Boolean,
        default: false
      },
      currentFunctionInfo: {
        type: Object,
        default: () => {}
      }
    },
    computed: {
      listenFuncChange() {
        console.log('listenFuncChange')
        const { visible, currentFunctionInfo } = this
        return { visible, currentFunctionInfo }
      }
    },
    watch: {
      listenFuncChange() {
        console.log('this.visible', this.visible)
        if (this.visible) {
          console.log('this.visible = true')
          this.onReset()
        }
      }
    },
    methods: {
      onReset() {
        const inputs = {}
        const inputArr = this.info?.input?.map((input, i) => {
          const key = `input_${i}`
          Object.assign(inputs, { [key]: input })
          return { key, input }
        })
        this.inputs = inputArr
        console.log(this.info)
        // this.form.setFieldsValue({
        //   name: this.currentFunctionInfo?.name,
        //   className: this.currentFunctionInfo?.className,
        //   output: this.currentFunctionInfo?.output,
        //   ...inputs
        // })
        // info => 初始化currentfunctioninfo
        // 修改info
      },
      onOpen() {
        // this.info = Object.assign(this.$parent.currentFunctionInfo)
        console.log('loadingdetail in onopen', this.$parent.loadingDetail)
      },
      onClose() {
        this.editable = false
        this.loadingSave = false
        // this.$parent.currentFunctionInfo = {}
        // this.$parent.closeDetail()
      },
      onChgEditable() {
        this.editable = true
        this.onReset()
      },
      cancelEdit() {
        this.onReset()
        this.editable = false
        setTimeout(() => {
          this.onReset()
        })
      },
      saveEdit() {
        console.log(this.info)
      }
    }
  }
</script>

<style>
  .inputDefault {
    background: #00000000;
    cursor: auto;
    color: #000000a6;
  }
  .editable {
    border-color: #fff;
  }
  .editable:hover {
    border-color: #00000000;
  }
</style>
<style></style>
